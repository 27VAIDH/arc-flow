function f(o,s,t){const n=document.getElementById("arcflow-capture-popup");n&&n.remove();const e=document.createElement("div");e.id="arcflow-capture-popup",e.style.cssText=`
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.3);
    z-index: 99999;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `;const r=document.createElement("div");r.style.cssText=`
    background: #1e1e2e;
    color: #e0e0e0;
    border-radius: 12px;
    padding: 16px;
    max-width: 400px;
    width: 90%;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
    font-size: 13px;
  `;const x=document.createElement("div");x.style.cssText=`
    background: #2a2a3e;
    border-radius: 8px;
    padding: 10px;
    margin-bottom: 12px;
    max-height: 100px;
    overflow-y: auto;
    font-size: 12px;
    color: #b0b0c0;
    line-height: 1.4;
    border-left: 3px solid #7c5cfc;
  `;const b=o.length>200?o.slice(0,200)+"…":o;x.textContent=b;const u=document.createElement("div");u.style.cssText=`
    font-size: 11px;
    color: #888;
    margin-bottom: 12px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  `,u.textContent=`From: ${document.title}`;const m=document.createElement("div");m.style.cssText="font-size: 11px; color: #999; margin-bottom: 4px;",m.textContent="Add a note (optional):";const i=document.createElement("input");i.type="text",i.placeholder="Your annotation…",i.style.cssText=`
    width: 100%;
    box-sizing: border-box;
    background: #2a2a3e;
    border: 1px solid #444;
    border-radius: 6px;
    padding: 8px 10px;
    color: #e0e0e0;
    font-size: 12px;
    outline: none;
    margin-bottom: 12px;
  `;const d=document.createElement("div");d.style.cssText="display: flex; gap: 8px; justify-content: flex-end;";const p=document.createElement("button");p.textContent="Skip",p.style.cssText=`
    background: transparent;
    border: 1px solid #555;
    border-radius: 6px;
    padding: 6px 14px;
    color: #aaa;
    font-size: 12px;
    cursor: pointer;
  `;const l=document.createElement("button");l.textContent="Save",l.style.cssText=`
    background: #7c5cfc;
    border: none;
    border-radius: 6px;
    padding: 6px 14px;
    color: #fff;
    font-size: 12px;
    cursor: pointer;
  `,d.appendChild(p),d.appendChild(l),r.appendChild(x),r.appendChild(u),r.appendChild(m),r.appendChild(i),r.appendChild(d),e.appendChild(r),document.body.appendChild(e),setTimeout(()=>i.focus(),50);const a=()=>e.remove();l.addEventListener("click",()=>{s(i.value.trim()),a()}),p.addEventListener("click",()=>{t(),a()}),i.addEventListener("keydown",c=>{c.key==="Enter"&&(c.preventDefault(),s(i.value.trim()),a()),c.key==="Escape"&&(c.preventDefault(),t(),a())}),e.addEventListener("click",c=>{c.target===e&&(t(),a())})}chrome.runtime.onMessage.addListener((o,s,t)=>{if(o.type==="ARCFLOW_CAPTURE_SELECTION"){const n=o.selectedText||window.getSelection()?.toString()?.trim()||"";if(!n){t({action:"cancel"});return}return f(n,e=>{t({action:"save",annotation:e})},()=>{t({action:"save",annotation:""})}),!0}if(o.type==="ARCFLOW_CAPTURE_SNIPPET"){const n=o.selectedText||window.getSelection()?.toString()?.trim()||"";if(!n){t({action:"cancel"});return}return f(n,e=>{t({action:"save",annotation:e})},()=>{t({action:"cancel"})}),!0}o.type==="ARCFLOW_NOTES_FULL"&&alert("ArcFlow Notes: Notes are full (5,000 character limit reached). Please clear some notes first.")});
